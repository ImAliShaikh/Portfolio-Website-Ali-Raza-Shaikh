import React from 'react';
import { certifications } from '../data';
import { Award } from 'lucide-react';

interface CertificationsProps {
  darkMode: boolean;
}

const Certifications: React.FC<CertificationsProps> = ({ darkMode }) => {
  return (
    <section 
      id="certifications" 
      className={`py-20 ${
        darkMode 
          ? 'bg-gray-900 text-white' 
          : 'bg-blue-50 text-gray-900'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Certifications</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {certifications.map(cert => (
            <div 
              key={cert.id}
              className={`p-6 rounded-lg shadow-md ${
                darkMode ? 'bg-gray-800' : 'bg-white'
              } flex items-center transition-transform duration-300 hover:scale-[1.03]`}
            >
              <div className={`p-4 rounded-full mr-4 ${
                darkMode ? 'bg-gray-700' : 'bg-blue-100'
              }`}>
                <Award size={24} className="text-blue-600" />
              </div>
              <h3 className="text-lg font-medium">{cert.title}</h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;