import React from 'react';
import { skills } from '../data';
import { Brain, Code, Database, Layers, Settings } from 'lucide-react';

interface SkillsProps {
  darkMode: boolean;
}

const Skills: React.FC<SkillsProps> = ({ darkMode }) => {
  // Group skills by category
  const skillsByCategory = {
    ai: skills.filter(skill => skill.category === 'ai'),
    programming: skills.filter(skill => skill.category === 'programming'),
    data: skills.filter(skill => skill.category === 'data'),
    general: skills.filter(skill => skill.category === 'general'),
    framework: skills.filter(skill => skill.category === 'framework')
  };

  const getCategoryIcon = (category: string) => {
    switch(category) {
      case 'ai':
        return <Brain size={24} className="text-blue-600" />;
      case 'programming':
        return <Code size={24} className="text-blue-600" />;
      case 'data':
        return <Database size={24} className="text-blue-600" />;
      case 'framework':
        return <Layers size={24} className="text-blue-600" />;
      default:
        return <Settings size={24} className="text-blue-600" />;
    }
  };

  const getCategoryTitle = (category: string) => {
    switch(category) {
      case 'ai':
        return 'AI & Machine Learning';
      case 'programming':
        return 'Programming';
      case 'data':
        return 'Data Management';
      case 'framework':
        return 'Frameworks';
      default:
        return 'General Skills';
    }
  };

  const categories = ['ai', 'programming', 'data', 'framework', 'general'];

  return (
    <section 
      id="skills" 
      className={`py-20 ${
        darkMode 
          ? 'bg-gray-800 text-white' 
          : 'bg-white text-gray-900'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Skills</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map(category => (
            <div 
              key={category}
              className={`p-6 rounded-lg ${
                darkMode ? 'bg-gray-700' : 'bg-blue-50'
              } shadow-md`}
            >
              <div className="flex items-center mb-4">
                {getCategoryIcon(category)}
                <h3 className="text-xl font-semibold ml-3">{getCategoryTitle(category)}</h3>
              </div>
              
              <div className="space-y-4">
                {skillsByCategory[category as keyof typeof skillsByCategory].map(skill => (
                  <div key={skill.id}>
                    <div className="flex justify-between mb-1">
                      <span>{skill.name}</span>
                    </div>
                    <div 
                      className={`w-full h-2 rounded-full ${
                        darkMode ? 'bg-gray-600' : 'bg-gray-200'
                      }`}
                    >
                      <div 
                        className="h-full bg-blue-600 rounded-full"
                        style={{ width: `${75 + Math.random() * 25}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;