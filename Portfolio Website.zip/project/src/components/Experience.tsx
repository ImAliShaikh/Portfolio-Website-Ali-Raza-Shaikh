import React from 'react';
import { experience } from '../data';
import { Briefcase, Calendar } from 'lucide-react';

interface ExperienceProps {
  darkMode: boolean;
}

const Experience: React.FC<ExperienceProps> = ({ darkMode }) => {
  return (
    <section 
      id="experience" 
      className={`py-20 ${
        darkMode 
          ? 'bg-gray-900 text-white' 
          : 'bg-blue-50 text-gray-900'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Experience</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        
        <div className="space-y-8">
          {experience.map(exp => (
            <div 
              key={exp.id}
              className={`p-6 rounded-lg shadow-md ${
                darkMode ? 'bg-gray-800' : 'bg-white'
              } transition-transform duration-300 hover:scale-[1.02]`}
            >
              <div className="flex items-start">
                <div className={`p-3 rounded-full ${
                  darkMode ? 'bg-gray-700' : 'bg-blue-100'
                } mr-4`}>
                  <Briefcase size={24} className="text-blue-600" />
                </div>
                
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-1">
                    {exp.position}
                  </h3>
                  
                  {exp.company && (
                    <p className={`text-lg ${darkMode ? 'text-blue-400' : 'text-blue-600'} mb-2`}>
                      {exp.company}
                    </p>
                  )}
                  
                  <div className="flex items-center mb-4">
                    <Calendar size={16} className={`${darkMode ? 'text-gray-400' : 'text-gray-600'} mr-2`} />
                    <span className={`${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      {exp.period}
                    </span>
                  </div>
                  
                  {exp.responsibilities.length > 0 && (
                    <div className="mb-3">
                      <ul className={`list-disc list-inside ${darkMode ? 'text-gray-300' : 'text-gray-700'} space-y-1`}>
                        {exp.responsibilities.map((resp, index) => (
                          <li key={index}>{resp}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {exp.achievements && (
                    <div className={`mt-3 p-3 rounded-md ${
                      darkMode ? 'bg-gray-700 text-blue-300' : 'bg-blue-50 text-blue-700'
                    } font-medium`}>
                      {exp.achievements}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;