import React from 'react';
import { education } from '../data';
import { GraduationCap, MapPin } from 'lucide-react';

interface EducationProps {
  darkMode: boolean;
}

const Education: React.FC<EducationProps> = ({ darkMode }) => {
  return (
    <section 
      id="education" 
      className={`py-20 ${
        darkMode 
          ? 'bg-gray-900 text-white' 
          : 'bg-blue-50 text-gray-900'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Education</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        
        <div className="relative">
          {/* Timeline line */}
          <div 
            className={`absolute left-1/2 transform -translate-x-1/2 h-full w-1 ${
              darkMode ? 'bg-gray-700' : 'bg-blue-200'
            }`}
          ></div>
          
          <div className="space-y-12">
            {education.map((edu, index) => (
              <div 
                key={edu.id} 
                className={`relative ${index % 2 === 0 ? 'md:ml-auto md:pl-8' : 'md:mr-auto md:pr-8'} md:w-1/2`}
                data-aos={index % 2 === 0 ? "fade-left" : "fade-right"}
                data-aos-duration="1000"
              >
                {/* Timeline dot */}
                <div 
                  className="absolute left-1/2 top-0 transform -translate-x-1/2 w-5 h-5 rounded-full bg-blue-600"
                ></div>
                
                {/* Education card */}
                <div 
                  className={`p-6 rounded-lg shadow-md ${
                    darkMode ? 'bg-gray-800 hover:bg-gray-700' : 'bg-white hover:bg-blue-50'
                  } transition-colors duration-300`}
                >
                  <div className="flex items-center mb-2">
                    <GraduationCap size={20} className="text-blue-600 mr-2" />
                    <h3 className="text-xl font-semibold">{edu.degree}</h3>
                  </div>
                  
                  <p className={`text-lg font-medium ${darkMode ? 'text-blue-400' : 'text-blue-600'}`}>
                    {edu.institution}
                  </p>
                  
                  {edu.period && (
                    <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-2`}>
                      {edu.period}
                    </p>
                  )}
                  
                  <div className="flex items-center">
                    <MapPin size={16} className={`${darkMode ? 'text-gray-400' : 'text-gray-600'} mr-1`} />
                    <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      {edu.location}
                    </p>
                  </div>
                  
                  {edu.achievements && (
                    <p className={`mt-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {edu.achievements}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;