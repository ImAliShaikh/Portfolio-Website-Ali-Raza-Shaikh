import React, { useState, useRef } from 'react';
import { Mail, MapPin } from 'lucide-react';
import emailjs from '@emailjs/browser';
import toast, { Toaster } from 'react-hot-toast';

interface ContactProps {
  darkMode: boolean;
}

const Contact: React.FC<ContactProps> = ({ darkMode }) => {
  const form = useRef<HTMLFormElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!form.current) return;
    
    try {
      setIsSubmitting(true);
      
      await emailjs.init("KKwm0H7TsZMk_mDr-");
      
      await emailjs.sendForm(
        'service_3r1s0os',
        'template_uxt42xr',
        form.current
      );
      
      toast.success('Message sent successfully!');
      form.current.reset();
    } catch (error) {
      toast.error('Failed to send message. Please try again.');
      console.error('Error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <section 
      id="contact" 
      className={`py-20 ${
        darkMode 
          ? 'bg-gray-800 text-white' 
          : 'bg-white text-gray-900'
      }`}
    >
      <Toaster position="top-right" />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-semibold mb-6">Contact Information</h3>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start">
                <div className={`p-3 rounded-full ${
                  darkMode ? 'bg-gray-700' : 'bg-blue-100'
                } mr-4`}>
                  <MapPin size={20} className="text-blue-600" />
                </div>
                <div>
                  <h4 className="text-lg font-medium mb-1">Location</h4>
                  <p className={`${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Karachi, Pakistan
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className={`p-3 rounded-full ${
                  darkMode ? 'bg-gray-700' : 'bg-blue-100'
                } mr-4`}>
                  <Mail size={20} className="text-blue-600" />
                </div>
                <div>
                  <h4 className="text-lg font-medium mb-1">Email</h4>
                  <a 
                    href="mailto:alirazashaikh2002@gmail.com" 
                    className="text-blue-600 hover:underline"
                  >
                    alirazashaikh2002@gmail.com
                  </a>
                </div>
              </div>
            </div>
            
            <div className={`p-6 rounded-lg ${
              darkMode ? 'bg-gray-700' : 'bg-blue-50'
            }`}>
              <h4 className="text-lg font-medium mb-3">Connect With Me</h4>
              <p className={`mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                I'm always open to discussing new projects, creative ideas or opportunities to be part of your vision.
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-semibold mb-6">Send Me a Message</h3>
            
            <form ref={form} onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label 
                    htmlFor="from_name" 
                    className={`block mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}
                  >
                    Your Name <span className="text-red-500">*</span>
                  </label>
                  <input 
                    type="text" 
                    id="from_name"
                    name="from_name"
                    required
                    className={`w-full px-4 py-3 rounded-md ${
                      darkMode 
                        ? 'bg-gray-700 border-gray-600 text-white' 
                        : 'bg-gray-100 border-gray-300 text-gray-900'
                    } border focus:outline-none focus:ring-2 focus:ring-blue-600`}
                  />
                </div>
                
                <div>
                  <label 
                    htmlFor="from_email" 
                    className={`block mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}
                  >
                    Your Email <span className="text-red-500">*</span>
                  </label>
                  <input 
                    type="email" 
                    id="from_email"
                    name="from_email"
                    required
                    className={`w-full px-4 py-3 rounded-md ${
                      darkMode 
                        ? 'bg-gray-700 border-gray-600 text-white' 
                        : 'bg-gray-100 border-gray-300 text-gray-900'
                    } border focus:outline-none focus:ring-2 focus:ring-blue-600`}
                  />
                </div>
              </div>
              
              <div className="mb-6">
                <label 
                  htmlFor="subject" 
                  className={`block mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}
                >
                  Subject
                </label>
                <input 
                  type="text" 
                  id="subject"
                  name="subject"
                  className={`w-full px-4 py-3 rounded-md ${
                    darkMode 
                      ? 'bg-gray-700 border-gray-600 text-white' 
                      : 'bg-gray-100 border-gray-300 text-gray-900'
                  } border focus:outline-none focus:ring-2 focus:ring-blue-600`}
                />
              </div>
              
              <div className="mb-6">
                <label 
                  htmlFor="message" 
                  className={`block mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}
                >
                  Your Message <span className="text-red-500">*</span>
                </label>
                <textarea 
                  id="message"
                  name="message"
                  required
                  rows={5}
                  className={`w-full px-4 py-3 rounded-md ${
                    darkMode 
                      ? 'bg-gray-700 border-gray-600 text-white' 
                      : 'bg-gray-100 border-gray-300 text-gray-900'
                  } border focus:outline-none focus:ring-2 focus:ring-blue-600`}
                ></textarea>
              </div>
              
              <button 
                type="submit"
                disabled={isSubmitting}
                className={`w-full px-6 py-3 bg-blue-600 text-white rounded-md transition-colors duration-300 ${
                  isSubmitting ? 'opacity-70 cursor-not-allowed' : 'hover:bg-blue-700'
                }`}
              >
                {isSubmitting ? 'Sending...' : 'Send Message'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;