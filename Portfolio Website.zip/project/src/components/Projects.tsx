import React, { useState } from 'react';
import { projects } from '../data';
import { Calendar, ExternalLink } from 'lucide-react';

interface ProjectsProps {
  darkMode: boolean;
}

const Projects: React.FC<ProjectsProps> = ({ darkMode }) => {
  const [filter, setFilter] = useState<number | null>(null);
  const years = [...new Set(projects.map(project => project.year))].sort((a, b) => b - a);
  
  const filteredProjects = filter ? projects.filter(project => project.year === filter) : projects;
  
  const getProjectImage = (title: string) => {
    switch(title) {
      case "Point Reservation System":
        return "https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg";
      case "Breast Cancer Prediction Model":
        return "https://images.pexels.com/photos/3825586/pexels-photo-3825586.jpeg";
      case "Vehicle Detection & Counting System":
        return "https://images.pexels.com/photos/3729464/pexels-photo-3729464.jpeg";
      case "Covid-19 Ambulance Reservation":
        return "https://images.pexels.com/photos/4386466/pexels-photo-4386466.jpeg";
      case "CAFE-WIFI-AND-HOTSPOT-MANAGEMENT-SYSTEM":
        return "https://images.pexels.com/photos/4974914/pexels-photo-4974914.jpeg";
      case "Point Reservation System (SDA)":
        return "https://images.pexels.com/photos/3183153/pexels-photo-3183153.jpeg";
      case "AI Code Breaker Game":
        return "https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg";
      case "Airport Management System":
        return "https://images.pexels.com/photos/358319/pexels-photo-358319.jpeg";
      default:
        return "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg";
    }
  };

  return (
    <section 
      id="projects" 
      className={`py-20 ${
        darkMode 
          ? 'bg-gray-800 text-white' 
          : 'bg-white text-gray-900'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Projects</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            <button
              onClick={() => setFilter(null)}
              className={`px-4 py-2 rounded-md transition-colors duration-300 ${
                filter === null
                  ? 'bg-blue-600 text-white'
                  : darkMode 
                    ? 'bg-gray-700 hover:bg-gray-600 text-white' 
                    : 'bg-gray-200 hover:bg-gray-300 text-gray-800'
              }`}
            >
              All
            </button>
            
            {years.map(year => (
              <button
                key={year}
                onClick={() => setFilter(year)}
                className={`px-4 py-2 rounded-md transition-colors duration-300 ${
                  filter === year
                    ? 'bg-blue-600 text-white'
                    : darkMode 
                      ? 'bg-gray-700 hover:bg-gray-600 text-white' 
                      : 'bg-gray-200 hover:bg-gray-300 text-gray-800'
                }`}
              >
                {year}
              </button>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map(project => (
            <div 
              key={project.id}
              className={`rounded-lg overflow-hidden shadow-md group ${
                darkMode ? 'bg-gray-700 hover:shadow-blue-600/20' : 'bg-white hover:shadow-lg'
              } transition-all duration-300 hover:-translate-y-2`}
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={getProjectImage(project.title)}
                  alt={project.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              
              <div className="p-6">
                <div className="flex items-center mb-3">
                  <Calendar size={16} className="text-blue-600 mr-2" />
                  <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {project.year}
                  </span>
                </div>
                
                <h3 className="text-xl font-semibold mb-3 group-hover:text-blue-600 transition-colors duration-300">
                  {project.title}
                </h3>
                
                <p className={`mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech, index) => (
                    <span 
                      key={index}
                      className={`text-xs px-3 py-1 rounded-full ${
                        darkMode ? 'bg-gray-600 text-gray-300' : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                
                <a 
                  href="#" 
                  className="inline-flex items-center text-blue-600 hover:text-blue-700 transition-colors duration-300"
                >
                  <span className="mr-1">View Project</span>
                  <ExternalLink size={16} />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;