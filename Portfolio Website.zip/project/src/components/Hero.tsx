import React from 'react';
import { Github as GitHub, Linkedin, Mail } from 'lucide-react';

interface HeroProps {
  darkMode: boolean;
}

const Hero: React.FC<HeroProps> = ({ darkMode }) => {
  return (
    <section 
      id="home" 
      className={`min-h-screen flex items-center justify-center ${
        darkMode ? 'bg-gray-900 text-white' : 'bg-gradient-to-br from-blue-50 to-white text-gray-900'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-blue-400">
            Hi, I'm Ali Raza Shaikh
          </h1>
          <p className="text-xl md:text-2xl mb-6">
            AI Enthusiast & Software Developer
          </p>
          <p className={`text-lg mb-8 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
            Passionate about creating intelligent systems that solve real-world problems
          </p>
          
          <div className="flex flex-wrap gap-4 justify-center mb-8">
            <a 
              href="#contact" 
              className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-300"
            >
              Get In Touch
            </a>
            <a 
              href="#projects" 
              className={`px-6 py-3 rounded-md border transition-colors duration-300 ${
                darkMode 
                  ? 'border-gray-600 hover:bg-gray-800' 
                  : 'border-gray-300 hover:bg-gray-100'
              }`}
            >
              View Work
            </a>
          </div>
          
          <div className="flex justify-center space-x-6">
            <a 
              href="https://github.com/ImAliShaikh" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="hover:text-blue-600 transition-colors duration-300"
            >
              <GitHub size={28} />
            </a>
            <a 
              href="http://linkedin.com/in/ali-raza-shaikh-257656260" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="hover:text-blue-600 transition-colors duration-300"
            >
              <Linkedin size={28} />
            </a>
            <a 
              href="mailto:alirazashaikh2002@gmail.com" 
              className="hover:text-blue-600 transition-colors duration-300"
            >
              <Mail size={28} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;