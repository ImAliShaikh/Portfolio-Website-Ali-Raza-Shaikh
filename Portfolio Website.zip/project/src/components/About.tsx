import React from 'react';
import { BookOpen, Brain, Code, Users } from 'lucide-react';

interface AboutProps {
  darkMode: boolean;
}

const About: React.FC<AboutProps> = ({ darkMode }) => {
  return (
    <section 
      id="about" 
      className={`py-20 ${
        darkMode 
          ? 'bg-gray-800 text-white' 
          : 'bg-white text-gray-900'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">About Me</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <div className={`rounded-lg overflow-hidden ${darkMode ? 'shadow-blue-600/20' : 'shadow-lg'}`}>
              <img 
                src="https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Ali Raza Shaikh Working" 
                className="w-full h-full object-cover" 
              />
            </div>
          </div>
          
          <div>
            <p className={`text-lg mb-6 leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              I'm an AI enthusiast with strong technical skills in machine learning, image processing, and software development. 
              Currently pursuing a Computer Science degree at FAST NUCES, I'm focused on advancing in deep learning, 
              computer vision, and AI agents.
            </p>
            <p className={`text-lg mb-6 leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              My passion lies in creating intelligent systems that address real-world challenges. I combine technical rigor 
              with creative problem-solving, as evidenced by my hackathon success developing solutions for Pakistani farmers.
            </p>
            <p className={`text-lg mb-8 leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Beyond academics, I'm active in the tech community, mentoring younger students and exploring AI ethics 
              through technical discussions.
            </p>
            
            <div className="grid grid-cols-2 gap-6">
              <div className={`p-4 rounded-lg ${
                darkMode ? 'bg-gray-700' : 'bg-blue-50'
              } flex items-center`}>
                <Brain className="mr-3 text-blue-600" size={24} />
                <span>AI Research</span>
              </div>
              <div className={`p-4 rounded-lg ${
                darkMode ? 'bg-gray-700' : 'bg-blue-50'
              } flex items-center`}>
                <Code className="mr-3 text-blue-600" size={24} />
                <span>Software Dev</span>
              </div>
              <div className={`p-4 rounded-lg ${
                darkMode ? 'bg-gray-700' : 'bg-blue-50'
              } flex items-center`}>
                <BookOpen className="mr-3 text-blue-600" size={24} />
                <span>Teaching</span>
              </div>
              <div className={`p-4 rounded-lg ${
                darkMode ? 'bg-gray-700' : 'bg-blue-50'
              } flex items-center`}>
                <Users className="mr-3 text-blue-600" size={24} />
                <span>Mentoring</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;