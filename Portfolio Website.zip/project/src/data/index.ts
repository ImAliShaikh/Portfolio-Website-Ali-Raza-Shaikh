import { CertificationType, EducationType, ExperienceType, ProjectType, SkillType } from "../types";

export const education: EducationType[] = [
  {
    id: 1,
    degree: "BS Computer Science",
    institution: "National University of Computing and Emerging Sciences (FAST)",
    period: "August 2022 - Present",
    location: "Karachi, Pakistan",
    achievements: "CGPA: 3.1"
  },
  {
    id: 2,
    degree: "A levels",
    institution: "Blue Jays School System",
    period: "August 2020 - May 2022",
    location: "Hyderabad, Pakistan",
    achievements: "Results: 1A*, 2A"
  },
  {
    id: 3,
    degree: "O levels",
    institution: "Beacon House School System",
    period: "",
    location: "Hyderabad, Pakistan",
    achievements: "Results: 3A*, 6A"
  }
];

export const experience: ExperienceType[] = [
  {
    id: 1,
    position: "Teaching Assistant – Differential Equations",
    company: "FAST NUCES University",
    period: "January 2025 – Present",
    responsibilities: [
      "Assisting in conducting labs, managing student queries, and grading assignments",
      "Helping clarify mathematical concepts and problem-solving strategies"
    ]
  },
  {
    id: 2,
    position: "Data Science Community Competitions Coordinator",
    company: "FAST University",
    period: "2024",
    responsibilities: [
      "Managed and coordinated participants in the competition"
    ]
  },
  {
    id: 3,
    position: "FAST PROCOM EVENT Participant",
    company: "",
    period: "2024",
    responsibilities: [],
    achievements: "Winner of Hackathon at FAST Procom - Developed an innovative solution to support Pakistani farmers"
  }
];

export const projects: ProjectType[] = [
  {
    id: 1,
    title: "Point Reservation System",
    description: "Developed a seat reservation system with virtual card generation",
    technologies: ["Django", "HTML-CSS", "PostgreSQL"],
    year: 2024
  },
  {
    id: 2,
    title: "Breast Cancer Prediction Model",
    description: "Built ML model using scikit-learn to predict tumor behavior, trained on medical datasets",
    technologies: ["Python", "scikit-learn", "Data Analytics"],
    year: 2024
  },
  {
    id: 3,
    title: "Vehicle Detection & Counting System",
    description: "Implemented real-time vehicle detection from CCTV footage",
    technologies: ["Python", "OpenCV", "MediaPipe"],
    year: 2025
  },
  {
    id: 4,
    title: "Covid-19 Ambulance Reservation",
    description: "Designed system for COVID-19 patients across Karachi using heap, queue, stack, and linked lists",
    technologies: ["C++", "Data Structures", "Algorithms"],
    year: 2023
  },
  {
    id: 5,
    title: "CAFE-WIFI-AND-HOTSPOT-MANAGEMENT-SYSTEM",
    description: "Designed a scalable WiFi system with four routers and four triple-layer switches in a symmetric layout",
    technologies: ["Network Design", "Router Configuration", "System Architecture"],
    year: 2024
  },
  {
    id: 6,
    title: "Point Reservation System (SDA)",
    description: "Created UML diagrams including Use Case, Class, and Activity diagrams using Papyrus",
    technologies: ["UML", "Papyrus", "Software Design"],
    year: 2024
  },
  {
    id: 7,
    title: "AI Code Breaker Game",
    description: "Developed a beginner-friendly AI web application with Python and Flask",
    technologies: ["Python", "Flask", "HTML", "AI Logic"],
    year: 2023
  },
  {
    id: 8,
    title: "Airport Management System",
    description: "Engineered a C-based solution for streamlining airport operations",
    technologies: ["C", "Data Structures", "System Design"],
    year: 2023
  }
];

export const skills: SkillType[] = [
  { id: 1, name: "Data Structures and Algorithms", category: "programming" },
  { id: 2, name: "Operating System", category: "general" },
  { id: 3, name: "DBMS (SQL, PostgreSQL)", category: "data" },
  { id: 4, name: "AI (ML, PyTorch, scikit-learn)", category: "ai" },
  { id: 5, name: "Object-Oriented Programming", category: "programming" },
  { id: 6, name: "Backend Development (Django)", category: "framework" },
  { id: 7, name: "Theory of Computation", category: "general" },
  { id: 8, name: "Data Analytics (Pandas, NumPy)", category: "data" },
  { id: 9, name: "Software Design (UML, Patterns)", category: "general" },
  { id: 10, name: "OpenCV and MediaPipe", category: "ai" }
];

export const certifications: CertificationType[] = [
  { id: 1, title: "Django Development" },
  { id: 2, title: "Machine Learning" },
  { id: 3, title: "Command Line in Linux" },
  { id: 4, title: "Python for Data Science" },
  { id: 5, title: "SQL" }
];

export const navLinks = [
  { id: 1, name: "Home", href: "#home" },
  { id: 2, name: "About", href: "#about" },
  { id: 3, name: "Education", href: "#education" },
  { id: 4, name: "Skills", href: "#skills" },
  { id: 5, name: "Experience", href: "#experience" },
  { id: 6, name: "Projects", href: "#projects" },
  { id: 7, name: "Certifications", href: "#certifications" },
  { id: 8, name: "Contact", href: "#contact" }
];