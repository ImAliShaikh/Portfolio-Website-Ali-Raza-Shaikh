export interface ProjectType {
  id: number;
  title: string;
  description: string;
  technologies: string[];
  year: number;
}

export interface EducationType {
  id: number;
  degree: string;
  institution: string;
  period: string;
  location: string;
  achievements?: string;
}

export interface ExperienceType {
  id: number;
  position: string;
  company: string;
  period: string;
  responsibilities: string[];
  achievements?: string;
}

export interface CertificationType {
  id: number;
  title: string;
}

export interface SkillType {
  id: number;
  name: string;
  category: 'ai' | 'programming' | 'data' | 'general' | 'framework';
}